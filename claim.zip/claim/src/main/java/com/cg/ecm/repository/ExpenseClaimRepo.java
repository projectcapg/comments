package com.cg.ecm.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.ecm.dto.ExpenseClaimed;

/**
 * Represents Repository
 * 
 * @author Durgesh Singh
 * @author Hari Galla
 * @author Soham Kasar
 * @author Lalit Kumar
 * @author Amanjot Singh
 * @author Adarsh Gupta
 * @author Vivek Kumar
 * @author Amit Yadav
 * @version 1.0
 */
@Repository
public interface ExpenseClaimRepo extends CrudRepository<ExpenseClaimed, Integer> {

}