package com.cg.ecm.exception;

/**
 * Represents Error Information
 * 
 * @author Durgesh Singh
 * @author Hari Galla
 * @author Soham Kasar
 * @author Lalit Kumar
 * @author Amanjot Singh
 * @author Adarsh Gupta
 * @author Vivek Kumar
 * @author Amit Yadav
 * @version 1.0
 */

public class ErrorInfo {

	private String url;
	private String message;
    
	
	public ErrorInfo(String url, String message)
	{
		this.url=url;
		this.message=message;
	}

	/**
     * Gets the String url.
     * 
     * @return a String representing url.
     */
	public String getUrl() {
		return url;
	}


	/**
     * Sets the String url.
     * 
     * @param String representing url.
     */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
     * Gets the message.
     * 
     * @return a String representing message.
     */
	public String getMessage() {
		return message;
	}


	/**
     * Gets the message.
     * 
     * @param a String representing message.
     */
	public void setMessage(String message) {
		this.message = message;
	}

	 /**
     * Returns Details
     * 
     * @return a string representing the details about ErrorInfo
     */
	@Override
	public String toString() {
		return "ErrorInfo [url=" + url + ", message=" + message + "]";
	}
}