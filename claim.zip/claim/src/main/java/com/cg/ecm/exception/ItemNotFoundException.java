package com.cg.ecm.exception;

/**
 * Represents Exception
 * 
 * @author Durgesh Singh
 * @author Hari Galla
 * @author Soham Kasar
 * @author Lalit Kumar
 * @author Amanjot Singh
 * @author Adarsh Gupta
 * @author Vivek Kumar
 * @author Amit Yadav
 * @version 1.0
 */
public class ItemNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	 /**
     * Create a default constructor
     * 
     */
	public ItemNotFoundException() {
		super();
	}


    /**
     * Creates a constructor with specified message 
     * 
     * @param message               The specified message.
     * @param cause                 The throwable cause
     * @param enableSuppression     For enableSuppression
     * @param writableStackTrace    For writableStackTrace
     */
	public ItemNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	/**
     * Creates a constructor with specified message 
     * 
     * @param message           The specified message.
     * @param cause             The throwable cause
     */
	public ItemNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
     * Creates a constructor with specified message 
     * 
     * @param message           The specified message.
     */
	public ItemNotFoundException(String message) {
		super(message);
	}

	/**
     * Creates a constructor with specified cause 
     * 
     * @param cause           The throwable cause.
     */
	public ItemNotFoundException(Throwable cause) {
		super(cause);
	}

}