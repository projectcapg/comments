package com.cg.ecm.exception;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;


/**
 * Represents Advice
 * 
 * @author Durgesh Singh
 * @author Hari Galla
 * @author Soham Kasar
 * @author Lalit Kumar
 * @author Amanjot Singh
 * @author Adarsh Gupta
 * @author Vivek Kumar
 * @author Amit Yadav
 * @version 1.0
 */
@ControllerAdvice
public class ItemServiceErrorAdvice {
	@ResponseBody
	@ResponseStatus(value=HttpStatus.NOT_FOUND)
	@ExceptionHandler(value=Exception.class)
	/**
	 * For handling conflict
	 * 
	 * @param An exception 'e'
	 * @param A HttpServletRequest 'request'
	 * @return String representing url and String representing body of response 
	 */
	protected ErrorInfo handleConflict(Exception e,HttpServletRequest request)
	{
		
		String bodyOfResponse=e.getMessage();
		String uri=request.getRequestURL().toString();
		System.out.println("Error Message: "+bodyOfResponse+" Req URL: "+uri);
		return new ErrorInfo(uri,bodyOfResponse);
	}


	/**
	 * To handle conflict
	 * 
	 * @param An Exception 'ItemNotFoundException'
	 * @return error
	 */
	@ExceptionHandler({ItemNotFoundException.class,SQLException.class})
	protected ResponseEntity<String> handleConflict2(ItemNotFoundException unf)
	{
		return error(HttpStatus.INTERNAL_SERVER_ERROR,unf);
		
	}


	/**
     * Sets the employee’s ID.
     * 
     * @param An exception 'ItemNotFoundException' and HttpStatus
     * @return A String representing specified message
     */
	protected ResponseEntity<String> error(HttpStatus status,ItemNotFoundException ee)
	{
		
		return ResponseEntity.status(status).body(ee.getMessage());
	}
}